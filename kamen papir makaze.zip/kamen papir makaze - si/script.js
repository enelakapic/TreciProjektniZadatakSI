let player1Choice = '';
let player2Choice = '';
let player1Name = '';
let player2Name = '';

function getResult(player1Choice, player2Choice) {
  if (player1Choice === player2Choice) {
    return "Izjednačeno! Ponovo pokušajte.";
  } else if (
    (player1Choice === "rock" && player2Choice === "scissors") ||
    (player1Choice === "paper" && player2Choice === "rock") ||
    (player1Choice === "scissors" && player2Choice === "paper")
  ) {
    return `${player1Name} je pobjedio/la!`;
  } else {
    return `${player2Name} je pobjedio/la!`;
  }
}

function startGame() {
  player1Name = document.getElementById('player1-name').value;
  player2Name = document.getElementById('player2-name').value;
  
  if (player1Name && player2Name) {
    document.getElementById('name-entry-section').style.display = 'none';
    document.getElementById('game-play-section').style.display = 'block';
    document.getElementById('player-turn').textContent = `${player1Name}, izaberite!`;
  } else {
    alert("Unesite imena oba igrača.");
  }
}


function endGame() {
  const resultMessage = getResult(player1Choice, player2Choice);
  document.getElementById('result-message').textContent = resultMessage;
  document.getElementById('game-play-section').style.display = 'none';
  document.getElementById('result-section').style.display = 'block';
}


function restartGame() {
  document.getElementById('name-entry-section').style.display = 'block';
  document.getElementById('result-section').style.display = 'none';
  player1Choice = '';
  player2Choice = '';
  document.getElementById('player1-name').value = '';
  document.getElementById('player2-name').value = '';
}


document.getElementById('start-game').addEventListener('click', startGame);


document.querySelectorAll('.choice').forEach(button => {
  button.addEventListener('click', function() {
    if (!player1Choice) {
      player1Choice = this.id;
      document.getElementById('player-turn').textContent = `${player2Name}, izaberite!`;
      return;
    }

    
    player2Choice = this.id;
    endGame();
  });
});


document.getElementById('restart-game').addEventListener('click', restartGame);
